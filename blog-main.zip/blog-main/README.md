Blog configuration.
