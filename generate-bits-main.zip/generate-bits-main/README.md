Update repositories:
* [technorabilia/docker-bits](https://github.com/technorabilia/docker-bits)
* [technorabilia/portainer-templates](https://github.com/technorabilia/portainer-templates)
