# getlsioapp.sh

Get LinuxServer.io application docker-compose configuration.

Usage:

```
# install once
sudo curl -sL https://git.io/JZarS -o /usr/local/bin/getlsioapp.sh
sudo chmod ugo+x /usr/local/bin/getlsioapp.sh

# run many times
getlsioapp.sh <application>
```
The application list you can choose from can be found at https://www.linuxserver.io/our-images.

or:

```
# run once
curl -sL https://git.io/JZarS | sh -s <application>
```

You can also specify a different BASEDIR:

```
BASEDIR=~/lsio getlsioapp.sh <application>
```

or:

```
curl -sL https://git.io/JZarS | BASEDIR=~/lsio sh -s <application>
```

Example output:

```
$ ./getlsioapp.sh sonarr
The following directories and files have been created:
   /srv/lsio/docker-env.cfg
   /srv/lsio/sonarr
   /srv/lsio/sonarr/downloads
   /srv/lsio/sonarr/.env
   /srv/lsio/sonarr/config
   /srv/lsio/sonarr/tv
   /srv/lsio/sonarr/docker-compose.yaml

Application setup:
1. Review the global settings in /srv/lsio/docker-env.cfg:
   #BASEDIR=/srv/lsio
   #PUID=1000
   #PGID=1000
   #TZ=Etc/UTC
2. Review /srv/lsio/sonarr/docker-compose.yaml
3. Create and start the application with:
   $ cd /srv/lsio/sonarr
   $ sudo docker-compose up -d
4. Stop and remove the application with:
   $ cd /srv/lsio/sonarr
   $ sudo docker-compose down
$
```

# synomeminfo.sh

Synology memory device information in RML.

Usage:

```
# install once
sudo curl -sL https://git.io/JZa4a -o /usr/local/bin/synomeminfo.sh
sudo chmod ugo+x /usr/local/bin/synomeminfo.sh

# run many times
synomeminfo.sh
```

or:

```
# run once
curl -sL https://git.io/JZa4a | sh
```

Example output:

```
$ synomeminfo.sh
Model: DS716+
Melding non-Synology memory module: Ja/Nee

[table border=1 cellpadding=2 bordercolor=#000000]]
[tr][th]Location[/th][th]Use[/th][th]Error Correction Type[/th][th]Maximum Capacity[/th][th]Number Of Devices[/th][/tr]
[tr][td]System Board Or Motherboard[/td][td]System Memory[/td][td]None[/td][td]8 GB[/td][td]2[/td][/tr]
[/table]
[table border=1 cellpadding=2 bordercolor=#000000]]
[tr][th]Total Width[/th][th]Data Width[/th][th]Size[/th][th]Form Factor[/th][th]Set[/th][th]Locator[/th][th]Bank Locator[/th][th]Type[/th][th]Type Detail[/th][th]Speed[/th][th]Manufacturer[/th][th]Part Number[/th][th]Rank[/th][th]Configured Memory Speed[/th][th]Minimum Voltage[/th][th]Maximum Voltage[/th][th]Configured Voltage[/th][/tr]
[tr][td]8 bits[/td][td]8 bits[/td][td]8192 MB[/td][td]SODIMM[/td][td]None[/td][td]ChannelA-DIMM0[/td][td]BANK 0[/td][td]DDR3[/td][td]Synchronous[/td][td]1600 MT/s[/td][td]1315[/td][td]CT102464BF160B.C16 [url=https://www.google.com/search?q=CT102464BF160B.C16][small](Google)[/small][/url] [url=https://tweakers.net/pricewatch/zoeken/?keyword=CT102464BF160B.C16][small](Pricewatch)[/small][/url][/td][td]Unknown[/td][td]1600 MT/s[/td][td]1.35 V[/td][td]1.5 V[/td][td]Unknown[/td][/tr]
[/table]
$
```
