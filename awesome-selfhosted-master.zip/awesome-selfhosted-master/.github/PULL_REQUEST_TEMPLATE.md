Please do not submit pull requests in this repository. Use https://github.com/awesome-selfhosted/awesome-selfhosted-data instead.
