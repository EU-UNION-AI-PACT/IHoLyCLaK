# Awesome Listen & Repos für VRAM, vGPU, vCPU, vRAM und virtuelle Ressourcen

Hier findest du spezialisierte Repos, Tools und Awesome-Listen, die sich mit Virtualisierung, GPU/RAM/CPU-Sharing, vGPU/vCPU/vRAM, Disaggregated/Composable Infrastructure und verwandten Themen beschäftigen.

---

## 🧠 vGPU (Virtual GPU), GPU-Sharing

- **NVIDIA vGPU**  
  - [Offizielle Infos & Docs](https://docs.nvidia.com/grid/)  
  - [NVIDIA vGPU GitHub](https://github.com/NVIDIA/vgpu-proxy)  
  - [Awesome vGPU](https://github.com/visheratin/awesome-vgpu) – Ressourcen, Papers, Implementierungen

- **AMD MxGPU**  
  - [AMD MxGPU (SR-IOV)](https://www.amd.com/en/technologies/sr-iov)

- **Intel GVT-g**  
  - [Intel GVT-g vGPU](https://github.com/intel/gvt-linux) – Intel GPU Sharing für VMs

- **GPU Sharing für K8s**  
  - [NVIDIA Device Plugin for Kubernetes](https://github.com/NVIDIA/k8s-device-plugin)
  - [KubeVirt GPU Passthrough](https://github.com/kubevirt/kubevirt)

- **Open-Source vGPU/Proxy**  
  - [vgpu_unlock](https://github.com/mbilker/vgpu_unlock) – Unlock Consumer GPUs für vGPU
  - [vgpu-proxy](https://github.com/NVIDIA/vgpu-proxy) – vGPU in VMs ohne Grid-Lizenz

---

## 🖥️ vCPU, Multi-CPU, CPU-Sharing

- **QEMU/KVM**  
  - [QEMU](https://github.com/qemu/qemu) – Virtuelle CPUs, NUMA, vCPU-Zuweisung
  - [libvirt](https://github.com/libvirt/libvirt) – Verwaltung von vCPUs, Topologien, Pinning

- **Kubernetes CPU-Management**  
  - [K8s CPU Manager](https://kubernetes.io/docs/tasks/administer-cluster/cpu-management-policies/)
  - [KubeVirt](https://github.com/kubevirt/kubevirt) – VMs mit CPU/RAM/GPU-Sharing auf K8s

- **OpenStack Nova**  
  - [OpenStack Nova](https://github.com/openstack/nova) – vCPU/vRAM/vGPU für VMs

---

## 💾 vRAM, RAM-Sharing, Memory Overcommit

- **zRAM/zswap**  
  - [zRAM Linux Kernel](https://www.kernel.org/doc/html/latest/blockdev/zram.html)
  - [zswap](https://www.kernel.org/doc/html/latest/admin-guide/mm/zswap.html)

- **Persistent Memory (PMEM)**  
  - [Intel Optane PMEM](https://github.com/intel/pmem)
  - [Awesome Persistent Memory](https://github.com/pmem/awesome-pmem)

- **Distributed Memory / Remote RAM**  
  - [MemVerge Memory Machine](https://www.memverge.com/)
  - [Awesome Disaggregated Memory](https://github.com/epfl-dc/awesome-disaggregated-memory)

---

## 🏗️ Composable/Disaggregated Infrastructure, Virtual Resource Pools

- **Awesome Composable Infrastructure**  
  - [Awesome Composable Infrastructure](https://github.com/Arachnid/awesome-composable-infrastructure)

- **OpenNebula**  
  - [https://github.com/OpenNebula/one](https://github.com/OpenNebula/one) – Echt virtuelle Ressourcenpools

- **Liqid Composable Infrastructure**  
  - [Liqid](https://github.com/LiqidInc) (Enterprise, aber viele Whitepapers/Architekturinfos)

- **HPE Synergy**  
  - [HPE Synergy Whitepapers](https://www.hpe.com/us/en/integrated-systems/synergy.html) – Referenz für Composable Infrastructure

---

## 📚 Hintergrund/Übersichten

- [Awesome Virtualization](https://github.com/Santosh-Gupta/awesome-virtualization)
- [Awesome Cloud Native](https://github.com/rootsongjc/awesome-cloud-native)
- [Awesome HPC](https://github.com/awesome-hpc/awesome-hpc)
- [Awesome Disaggregated Systems](https://github.com/epfl-dc/awesome-disaggregated-systems)
- [Awesome Edge Computing](https://github.com/benhamner/awesome-edge-computing)

---

**Tipp:**  
Viele dieser Technologien werden im Enterprise-Bereich eingesetzt, aber auch im Open-Source-Umfeld (K8s, QEMU, KubeVirt, vgpu_unlock) lässt sich vieles realisieren.  
Für konkrete Setups (z.B. Portainer-Stack, K8s-Cluster mit vGPU/vCPU/vRAM) helfe ich gern mit Beispielen!