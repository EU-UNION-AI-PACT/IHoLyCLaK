# Weitere Awesome-Listen (Ergänzung zu Server, DevOps, Selfhosting, IT etc.)

## ☁️ Cloud & Infrastruktur
- [Awesome Cloud](https://github.com/Cloud-Architects/awesome-cloud)
- [Awesome AWS](https://github.com/donnemartin/awesome-aws)
- [Awesome Azure](https://github.com/Azure/awesome-azure)
- [Awesome GCP](https://github.com/GoogleCloudPlatform/awesome-gcp)
- [Awesome Serverless](https://github.com/anaibol/awesome-serverless)
- [Awesome SaaS](https://github.com/FrancescoXX/awesome-saas)
- [Awesome Cloud Native](https://github.com/rootsongjc/awesome-cloud-native)

## 🔒 Security & Privacy
- [Awesome Security](https://github.com/sbilly/awesome-security)
- [Awesome Privacy](https://github.com/pluja/awesome-privacy)
- [Awesome GDPR](https://github.com/burningtree/awesome-gdpr)
- [Awesome Honeypots](https://github.com/paralax/awesome-honeypots)
- [Awesome Threat Intelligence](https://github.com/hslatman/awesome-threat-intelligence)
- [Awesome Web Security](https://github.com/qazbnm456/awesome-web-security)
- [Awesome Cryptography](https://github.com/sobolevn/awesome-cryptography)
- [Awesome Malware Analysis](https://github.com/rshipp/awesome-malware-analysis)
- [Awesome Security News](https://github.com/fabacab/awesome-security-news)

## 📊 Monitoring, Logging, Observability
- [Awesome Monitoring](https://github.com/crazy-canux/awesome-monitoring)
- [Awesome Observability](https://github.com/adriannadiaz/awesome-observability)
- [Awesome Prometheus](https://github.com/roaldnefs/awesome-prometheus)
- [Awesome Grafana](https://github.com/ryanmaclean/awesome-grafana)
- [Awesome Logging](https://github.com/wojciechmigda/awesome-logging)
- [Awesome Dashboards](https://github.com/obazoud/awesome-dashboard)

## 🛠️ Admin, Deployment, Automation
- [Awesome Ansible](https://github.com/roaldnefs/awesome-ansible)
- [Awesome Terraform](https://github.com/shuaibiyy/awesome-terraform)
- [Awesome Packer](https://github.com/stackbithq/awesome-packer)
- [Awesome Vagrant](https://github.com/iJackUA/awesome-vagrant)
- [Awesome Configuration Management](https://github.com/owainlewis/awesome-configuration-management)
- [Awesome Automation](https://github.com/KadenZe/awesome-automation)
- [Awesome Infrastructure Automation](https://github.com/DavidLambauer/awesome-infrastructure-automation)

## 🗄️ Datenbanken, Storage & Backup
- [Awesome Database](https://github.com/numetriclabz/awesome-db)
- [Awesome Postgres](https://github.com/dhamaniasad/awesome-postgres)
- [Awesome MySQL](https://github.com/shlomi-noach/awesome-mysql)
- [Awesome Redis](https://github.com/JamzyWong/awesome-redis)
- [Awesome MongoDB](https://github.com/ramnes/awesome-mongodb)
- [Awesome Backup](https://github.com/awesome-backup/awesome-backup)
- [Awesome Time Series Database](https://github.com/ty4z2008/Qix/blob/master/awesome-database.md#time-series)

## 🕸️ Web, API & Frontend
- [Awesome Web](https://github.com/vinta/awesome-python#web-frameworks)
- [Awesome API](https://github.com/Kikobeats/awesome-api)
- [Awesome REST](https://github.com/marmelab/awesome-rest)
- [Awesome Static Website Services](https://github.com/agarrharr/awesome-static-website-services)
- [Awesome Web Performance](https://github.com/davidsonfellipe/awesome-wpo)
- [Awesome Web Components](https://github.com/mateusortiz/webcomponents-the-right-way)
- [Awesome JAMstack](https://github.com/automata/awesome-jamstack)

## 🧰 Sonstiges & Spezialthemen
- [Awesome Open Source](https://github.com/open-source-ideas/awesome-open-source-ideas)
- [Awesome Free Software](https://github.com/johnjago/awesome-free-software)
- [Awesome Analytics](https://github.com/onurakpolat/awesome-analytics)
- [Awesome Public Datasets](https://github.com/awesomedata/awesome-public-datasets)
- [Awesome Cheatsheets](https://github.com/LeCoupa/awesome-cheatsheets)
- [Awesome CLI Apps](https://github.com/agarrharr/awesome-cli-apps)
- [Awesome Shell](https://github.com/alebcay/awesome-shell)
- [Awesome Scripts](https://github.com/LeCoupa/awesome-cheatsheets#scripts)
- [Awesome GitHub](https://github.com/phillipadsmith/awesome-github)
- [Awesome Lists (Meta)](https://github.com/sindresorhus/awesome)
- [Awesome Lists by Topic](https://github.com/topics/awesome-list)

---

**Tipp:** Suche einfach auf GitHub mit awesome <Stichwort> (z.B. awesome cloud, awesome iac, awesome honeypot, awesome logging, awesome automation, awesome privacy, awesome devops, awesome selfhosted, awesome api, awesome db ...).  
So findest du praktisch für jeden Bereich eine Top-Liste!