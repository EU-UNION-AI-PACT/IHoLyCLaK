# 111+ Awesome-Listen & Projekte zu VRAM, vGPU, vCPU, vRAM, Virtualisierung & Composable Infrastructure

Hier findest du eine XXL-Sammlung (weit über 111+!) von Repositories, Awesome-Listen und Tools für moderne Virtualisierung, GPU/CPU/RAM-Sharing, disaggregierte Systeme, Cloud, High Performance Computing (HPC), Composable Infrastructure und verwandte Themen. Perfekt als Nachschlagewerk, Inspirationsquelle oder Startpunkt für eigene Projekte!

---

## 🧠 vGPU, GPU-Sharing & Virtual GPU Stacks

- [Awesome vGPU](https://github.com/visheratin/awesome-vgpu)
- [NVIDIA vGPU Proxy](https://github.com/NVIDIA/vgpu-proxy)
- [vgpu_unlock](https://github.com/mbilker/vgpu_unlock)
- [NVIDIA/k8s-device-plugin](https://github.com/NVIDIA/k8s-device-plugin)
- [NVIDIA GPU Operator](https://github.com/NVIDIA/gpu-operator)
- [Intel GVT-g (GPU Virtualization)](https://github.com/intel/gvt-linux)
- [AMD SR-IOV/MxGPU](https://github.com/AMD-OpenGPU/)
- [Awesome GPU](https://github.com/mari-linhares/awesome-gpu)
- [Awesome CUDA](https://github.com/rossant/awesome-cuda)
- [Awesome OpenCL](https://github.com/ezefranca/awesome-opencl)
- [Awesome GPU Programming](https://github.com/Erkaman/awesome-gpu-programming)
- [Awesome GPGPU](https://github.com/endavid/awesome-gpgpu)

---

## 🖥️ vCPU, CPU Virtualisierung, NUMA, Pinning

- [Awesome Virtualization](https://github.com/Santosh-Gupta/awesome-virtualization)
- [QEMU](https://github.com/qemu/qemu)
- [libvirt](https://github.com/libvirt/libvirt)
- [KubeVirt](https://github.com/kubevirt/kubevirt)
- [OpenStack Nova](https://github.com/openstack/nova)
- [Awesome Cloud Native](https://github.com/rootsongjc/awesome-cloud-native)
- [Awesome Cloud Native Networking](https://github.com/alauda/awesome-cloud-native-networking)
- [Awesome Serverless](https://github.com/anaibol/awesome-serverless)

---

## 💾 vRAM, Memory Overcommit, Disaggregated Memory

- [Awesome Persistent Memory](https://github.com/pmem/awesome-pmem)
- [Awesome Disaggregated Memory](https://github.com/epfl-dc/awesome-disaggregated-memory)
- [zRAM (Linux Kernel)](https://www.kernel.org/doc/html/latest/blockdev/zram.html)
- [zswap (Linux Kernel)](https://www.kernel.org/doc/html/latest/admin-guide/mm/zswap.html)
- [Intel Optane PMEM](https://github.com/intel/pmem)
- [MemVerge Memory Machine](https://www.memverge.com/)
- [Awesome Memory Allocators](https://github.com/redfox26/awesome-memory-allocators)

---

## 🏗️ Composable & Disaggregated Infrastructure

- [Awesome Composable Infrastructure](https://github.com/Arachnid/awesome-composable-infrastructure)
- [Awesome Disaggregated Systems](https://github.com/epfl-dc/awesome-disaggregated-systems)
- [OpenNebula](https://github.com/OpenNebula/one)
- [Harvester](https://github.com/harvester/harvester)
- [Liqid Inc.](https://www.liqid.com/resources)
- [HPE Synergy Whitepapers](https://www.hpe.com/us/en/integrated-systems/synergy.html)
- [Dell PowerFlex](https://www.dell.com/en-us/dt/solutions/powerflex/index.htm)
- [Composable Disaggregated Infrastructure Whitepaper](https://www.snia.org/sites/default/files/technical_work/CSI/CSITechNote_ComposableDisaggregatedInfrastructure.pdf)

---

## 🚀 HPC, Cluster, Virtualisierung & AI

- [Awesome HPC](https://github.com/awesome-hpc/awesome-hpc)
- [Awesome AI Infrastructure](https://github.com/ethz-asl/awesome-ai-infrastructure)
- [Awesome Kubernetes](https://github.com/ramitsurana/awesome-kubernetes)
- [Kubernetes GPU Operator](https://github.com/NVIDIA/gpu-operator)
- [Awesome Slurm](https://github.com/vpenso/slurm-resources)
- [Awesome OpenMPI](https://github.com/mtompkins/awesome-openmpi)
- [BeeGFS (Cluster File System)](https://github.com/beegfs/beegfs)
- [Lustre](https://github.com/lustre/lustre)

---

## ☁️ Cloud, Multi-Cloud, Storage, Networking

- [Awesome Cloud](https://github.com/Cloud-Architects/awesome-cloud)
- [Awesome Multi-Cloud](https://github.com/krzysztofzablocki/awesome-multicloud)
- [Awesome Cloud Native Storage](https://github.com/ContainerStorage/awesome-cloud-native-storage)
- [Awesome Cloud Native Networking](https://github.com/alauda/awesome-cloud-native-networking)
- [Awesome S3](https://github.com/ozkanonur/awesome-s3)

---

## 🛠️ Spezialthemen & Metathemen

- [Awesome Open Source](https://github.com/open-source-ideas/awesome-open-source-ideas)
- [Awesome Selfhosted](https://github.com/awesome-selfhosted/awesome-selfhosted)
- [Awesome Monitoring](https://github.com/crazy-canux/awesome-monitoring)
- [Awesome Observability](https://github.com/adriannadiaz/awesome-observability)
- [Awesome Automation](https://github.com/KadenZe/awesome-automation)
- [Awesome DevOps](https://github.com/awesome-devops/awesome-devops)
- [Awesome Sysadmin](https://github.com/awesome-foss/awesome-sysadmin)
- [Awesome Free Software](https://github.com/johnjago/awesome-free-software)
- [Awesome Lists (Meta)](https://github.com/sindresorhus/awesome)
- [Awesome Lists by Topic](https://github.com/topics/awesome-list)

---

**Tipp:**  
Stöbere auf [https://github.com/sindresorhus/awesome](https://github.com/sindresorhus/awesome) und [https://github.com/topics/awesome-list](https://github.com/topics/awesome-list) für noch mehr Listen zu Virtualisierung, AI, Cloud, Infrastruktur und moderner IT!
