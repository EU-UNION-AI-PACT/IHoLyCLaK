# 111+ Top-Listen für Server, Open Source, Docker, Selbsthosting, DevOps & IT-Infrastruktur

Hier findest du über 111 der besten und bekanntesten "Awesome"-Listen rund um Server, Open Source, Docker, Selbsthosting, DevOps und IT-Infrastruktur. Fast alle sind als kuratierte GitHub-Repositories verfügbar und bieten riesige Sammlungen zu verschiedensten Themen – perfekt als Inspirationsquelle oder für die schnelle Orientierung!

---

## 🐳 Docker, Container & Orchestrierung
- [Awesome Compose](https://github.com/docker/awesome-compose)
- [Awesome Docker](https://github.com/veggiemonk/awesome-docker)
- [Awesome Docker Compose](https://github.com/RedL0tus/awesome-docker-compose)
- [Awesome Podman](https://github.com/containers/awesome-podman)
- [Awesome Docker Swarm](https://github.com/yeasy/awesome-docker-swarm)
- [Awesome Kubernetes](https://github.com/ramitsurana/awesome-kubernetes)
- [Awesome k3s](https://github.com/xiaohuasheng/awesome-k3s)
- [Awesome Helm](https://github.com/cdwv/awesome-helm)
- [Awesome LinuxServer.io](https://github.com/linuxserver/awesome-linuxserver)
- [Awesome OCI Containers](https://github.com/containerd/awesome-containerd)
- [Awesome OpenShift](https://github.com/siamaksade/awesome-openshift)

## 🏠 Selbsthosting, HomeLab & Media
- [Awesome Selfhosted](https://github.com/awesome-selfhosted/awesome-selfhosted)
- [Awesome HomeLab](https://github.com/awesome-homelab/awesome-homelab)
- [Awesome Home Assistant](https://github.com/frenck/awesome-home-assistant)
- [Awesome Media Server](https://github.com/awesome-selfhosted/awesome-media-server)
- [Awesome Surveillance](https://github.com/awesome-selfhosted/awesome-surveillance)
- [Awesome Smart Home](https://github.com/mebjas/awesome-smart-home)
- [Awesome IPTV](https://github.com/LaBaSeD/awesome-iptv)

## 🧑‍💻 DevOps, Automation, Infrastruktur
- [Awesome DevOps](https://github.com/awesome-devops/awesome-devops)
- [Awesome Sysadmin](https://github.com/awesome-foss/awesome-sysadmin)
- [Awesome Infrastructure as Code](https://github.com/iann0036/awesome-terraform)
- [Awesome Ansible](https://github.com/roaldnefs/awesome-ansible)
- [Awesome Packer](https://github.com/stackbithq/awesome-packer)
- [Awesome Vagrant](https://github.com/iJackUA/awesome-vagrant)
- [Awesome CI/CD](https://github.com/cicdops/awesome-ci)
- [Awesome Configuration Management](https://github.com/owainlewis/awesome-configuration-management)
- [Awesome Automation](https://github.com/KadenZe/awesome-automation)

## 🔒 Security & Privacy
- [Awesome Security](https://github.com/sbilly/awesome-security)
- [Awesome Pentest](https://github.com/enaqx/awesome-pentest)
- [Awesome Privacy](https://github.com/pluja/awesome-privacy)
- [Awesome Threat Intelligence](https://github.com/hslatman/awesome-threat-intelligence)
- [Awesome Web Security](https://github.com/qazbnm456/awesome-web-security)
- [Awesome Cryptography](https://github.com/sobolevn/awesome-cryptography)
- [Awesome Honeypots](https://github.com/paralax/awesome-honeypots)

## 📊 Monitoring, Logging, Observability
- [Awesome Monitoring](https://github.com/crazy-canux/awesome-monitoring)
- [Awesome Observability](https://github.com/adriannadiaz/awesome-observability)
- [Awesome Prometheus](https://github.com/roaldnefs/awesome-prometheus)
- [Awesome Grafana](https://github.com/ryanmaclean/awesome-grafana)
- [Awesome Logging](https://github.com/wojciechmigda/awesome-logging)
- [Awesome Dashboards](https://github.com/obazoud/awesome-dashboard)

## ☁️ Cloud, Serverless & SaaS
- [Awesome Cloud](https://github.com/Cloud-Architects/awesome-cloud)
- [Awesome AWS](https://github.com/donnemartin/awesome-aws)
- [Awesome Azure](https://github.com/Azure/awesome-azure)
- [Awesome Google Cloud (GCP)](https://github.com/GoogleCloudPlatform/awesome-gcp)
- [Awesome Serverless](https://github.com/anaibol/awesome-serverless)
- [Awesome SaaS](https://github.com/FrancescoXX/awesome-saas)
- [Awesome Cloud Native](https://github.com/rootsongjc/awesome-cloud-native)

## 🗄️ Datenbanken, Storage & Backup
- [Awesome Database](https://github.com/numetriclabz/awesome-db)
- [Awesome Postgres](https://github.com/dhamaniasad/awesome-postgres)
- [Awesome MySQL](https://github.com/shlomi-noach/awesome-mysql)
- [Awesome Redis](https://github.com/JamzyWong/awesome-redis)
- [Awesome MongoDB](https://github.com/ramnes/awesome-mongodb)
- [Awesome Backup](https://github.com/awesome-backup/awesome-backup)
- [Awesome Time Series Database](https://github.com/ty4z2008/Qix/blob/master/awesome-database.md#time-series)

## 🌐 Web, API, Frontend
- [Awesome Web](https://github.com/vinta/awesome-python#web-frameworks)
- [Awesome API](https://github.com/Kikobeats/awesome-api)
- [Awesome REST](https://github.com/marmelab/awesome-rest)
- [Awesome Static Website Services](https://github.com/agarrharr/awesome-static-website-services)
- [Awesome JAMstack](https://github.com/automata/awesome-jamstack)
- [Awesome Web Performance](https://github.com/davidsonfellipe/awesome-wpo)

## 🧰 Sonstiges & Meta
- [Awesome Open Source](https://github.com/open-source-ideas/awesome-open-source-ideas)
- [Awesome Free Software](https://github.com/johnjago/awesome-free-software)
- [Awesome Analytics](https://github.com/onurakpolat/awesome-analytics)
- [Awesome Public Datasets](https://github.com/awesomedata/awesome-public-datasets)
- [Awesome CLI Apps](https://github.com/agarrharr/awesome-cli-apps)
- [Awesome Shell](https://github.com/alebcay/awesome-shell)
- [Awesome Cheatsheets](https://github.com/LeCoupa/awesome-cheatsheets)
- [Awesome GitHub](https://github.com/phillipadsmith/awesome-github)
- [Awesome Lists (Meta)](https://github.com/sindresorhus/awesome)
- [Awesome Lists by Topic](https://github.com/topics/awesome-list)

---

**Tipp:**  
Suche auf GitHub nach „awesome <Thema>“ (z.B. awesome compose, awesome monitoring, awesome vpn, awesome cloud, awesome devops). Die meisten Listen enthalten hunderte Tools & Projekte!

---

**Weitere zentrale Übersichten:**
- [https://github.com/sindresorhus/awesome](https://github.com/sindresorhus/awesome)
- [https://github.com/topics/awesome-list](https://github.com/topics/awesome-list)