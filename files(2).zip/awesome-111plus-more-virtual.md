# Noch mehr (weit über 111+) Awesome-Listen & Projekte zu vGPU, vRAM, vCPU, RAM-/GPU-/CPU-Sharing, Virtualisierung & moderner Infrastruktur

Hier findest du eine weitere große Auswahl an Listen, Repos und Ressourcen rund um Virtualisierung, vGPU, vCPU, vRAM, Composable/Disaggregated Infrastructure, Cluster, AI, HPC und Cloud. Viele davon bieten tiefergehende Linksammlungen und führen zu noch mehr spezialisierten Awesome-Listen.

---

## 🧠 vGPU, GPU Virtualisierung & GPU-Pooling

- [Awesome vGPU](https://github.com/visheratin/awesome-vgpu)
- [Awesome GPU](https://github.com/mari-linhares/awesome-gpu)
- [Awesome CUDA](https://github.com/rossant/awesome-cuda)
- [NVIDIA vGPU Proxy](https://github.com/NVIDIA/vgpu-proxy)
- [vgpu_unlock (Consumer-GPU für vGPU)](https://github.com/mbilker/vgpu_unlock)
- [NVIDIA/k8s-device-plugin](https://github.com/NVIDIA/k8s-device-plugin)
- [Awesome OpenCL](https://github.com/ezefranca/awesome-opencl)
- [Awesome GPU Programming](https://github.com/Erkaman/awesome-gpu-programming)

---

## 🖥️ vCPU, CPU-Sharing, CPU-Pools

- [Awesome Virtualization](https://github.com/Santosh-Gupta/awesome-virtualization)
- [KubeVirt (VMs auf Kubernetes)](https://github.com/kubevirt/kubevirt)
- [OpenStack Nova (vCPU/vRAM/vGPU)](https://github.com/openstack/nova)
- [libvirt (vCPU, NUMA, Pinning)](https://github.com/libvirt/libvirt)
- [QEMU (vCPU, Tuning, NUMA)](https://github.com/qemu/qemu)
- [Awesome Cloud Native](https://github.com/rootsongjc/awesome-cloud-native)

---

## 💾 vRAM, Memory Overcommit, RAM-Sharing

- [Awesome Persistent Memory](https://github.com/pmem/awesome-pmem)
- [Awesome Disaggregated Memory](https://github.com/epfl-dc/awesome-disaggregated-memory)
- [zRAM (Linux Kernel)](https://github.com/torvalds/linux/tree/master/drivers/block/zram)
- [zswap (Linux Kernel)](https://www.kernel.org/doc/html/latest/admin-guide/mm/zswap.html)
- [MemVerge Memory Machine](https://www.memverge.com/)
- [Awesome Memory Allocators](https://github.com/redfox26/awesome-memory-allocators)

---

## 🏗️ Composable & Disaggregated Infrastructure

- [Awesome Composable Infrastructure](https://github.com/Arachnid/awesome-composable-infrastructure)
- [Awesome Disaggregated Systems](https://github.com/epfl-dc/awesome-disaggregated-systems)
- [OpenNebula](https://github.com/OpenNebula/one)
- [Harvester (HCI & Composable)](https://github.com/harvester/harvester)
- [Liqid Inc.](https://www.liqid.com/resources)
- [HPE Synergy Whitepapers](https://www.hpe.com/us/en/integrated-systems/synergy.html)
- [Composable Disaggregated Infrastructure Whitepaper](https://www.snia.org/sites/default/files/technical_work/CSI/CSITechNote_ComposableDisaggregatedInfrastructure.pdf)

---

## 🚀 Cluster, HPC, AI-Infrastruktur

- [Awesome HPC](https://github.com/awesome-hpc/awesome-hpc)
- [Awesome AI Infrastructure](https://github.com/ethz-asl/awesome-ai-infrastructure)
- [Awesome Kubernetes](https://github.com/ramitsurana/awesome-kubernetes)
- [Awesome Slurm (HPC Scheduler)](https://github.com/vpenso/slurm-resources)
- [Awesome OpenMPI](https://github.com/mtompkins/awesome-openmpi)
- [BeeGFS (Cluster File System)](https://github.com/beegfs/beegfs)
- [Awesome ML Ops](https://github.com/visenger/awesome-mlops)
- [Awesome Deep Learning](https://github.com/ChristosChristofidis/awesome-deep-learning)

---

## ☁️ Cloud, Storage, Multi-Cloud

- [Awesome Cloud](https://github.com/Cloud-Architects/awesome-cloud)
- [Awesome Multi-Cloud](https://github.com/krzysztofzablocki/awesome-multicloud)
- [Awesome Cloud Native Storage](https://github.com/ContainerStorage/awesome-cloud-native-storage)
- [Awesome S3](https://github.com/ozkanonur/awesome-s3)
- [Awesome Serverless](https://github.com/anaibol/awesome-serverless)

---

## 🛠️ Noch mehr Metathemen & Übersichten

- [Awesome Open Source](https://github.com/open-source-ideas/awesome-open-source-ideas)
- [Awesome Selfhosted](https://github.com/awesome-selfhosted/awesome-selfhosted)
- [Awesome Monitoring](https://github.com/crazy-canux/awesome-monitoring)
- [Awesome Observability](https://github.com/adriannadiaz/awesome-observability)
- [Awesome Automation](https://github.com/KadenZe/awesome-automation)
- [Awesome DevOps](https://github.com/awesome-devops/awesome-devops)
- [Awesome Sysadmin](https://github.com/awesome-foss/awesome-sysadmin)
- [Awesome Free Software](https://github.com/johnjago/awesome-free-software)
- [Awesome Lists (Meta)](https://github.com/sindresorhus/awesome)
- [Awesome Lists by Topic](https://github.com/topics/awesome-list)

---

**Tipp:**  
Jede dieser Listen enthält oft Dutzende bis Hunderte von Links zu spezialisierten Sublisten, Tools, Papers, Frameworks und Projekten!  
Für spezielle Setups, Stacks oder Beispiele (z.B. Portainer, K8s, Slurm, AI, Storage) einfach nachfragen!