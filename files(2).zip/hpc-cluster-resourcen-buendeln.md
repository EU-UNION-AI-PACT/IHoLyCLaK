# HPC-Cluster: Ressourcen bündeln, um einen PC schneller zu machen (RAM, GPU, CPU)

## 1. Grundprinzip
Ein HPC-Cluster besteht aus mehreren miteinander verbundenen Rechnern (Nodes), die ihre Rechenleistung, RAM und ggf. GPU bündeln. Das Ziel: Große Aufgaben schneller lösen und mehr Ressourcen für anspruchsvolle Anwendungen bereitstellen.

## 2. Was ist technisch möglich?

### CPU & RAM bündeln (Distributed Computing)
- **Batch- und Paralleljobs:** Programme wie MPI, Slurm, PBS, Grid Engine teilen Aufgaben in Teiljobs auf, die auf vielen Rechnern parallel laufen.
- **Virtuelle Maschinen/Container:** Ressourcen können einzelnen VMs/Containern auf verschiedenen Nodes zugewiesen werden.
- **Remote Desktop/Thin Client:** Du kannst auf einem schwachen PC arbeiten und die Rechenleistung des Clusters nutzen (z. B. mit X2Go, NiceDCV, NoMachine).

### GPU bündeln / verteilen
- **Remote-GPU (vGPU):** NVIDIA vGPU, AMD MxGPU, Intel GVT-g – GPU-Ressourcen werden virtualisiert und auf VMs oder Container verteilt.
- **GPU-Passthrough:** Einzelne GPUs können per PCIe an virtuelle Maschinen durchgereicht werden.
- **GPU-Sharing via Kubernetes:** K8s + NVIDIA Device Plugin ermöglicht das Teilen von GPUs zwischen Container-Jobs.

### RAM bündeln/erweitern
- **Distributed Shared Memory:** Projekte wie OpenMosix (veraltet) oder neuere Forschungsprojekte versuchen, RAM über das Netzwerk zu teilen – in der Praxis selten performant.
- **Swap-over-Network:** Swapspace auf anderen Nodes nutzen (z. B. mit NBD, iSCSI, aber extrem langsam im Vergleich zu lokalem RAM).
- **Persistent Memory (PMEM):** Intel Optane als RAM-Erweiterung im Cluster (HighEnd!).

## 3. Tools & Projekte (Open Source & Enterprise)

- **Slurm:** [https://github.com/SchedMD/slurm](https://github.com/SchedMD/slurm) (HPC Scheduler)
- **Kubernetes:** [https://github.com/kubernetes/kubernetes](https://github.com/kubernetes/kubernetes) (Container-Orchestrierung, auch für GPU/AI)
- **OpenMPI:** [https://github.com/open-mpi/ompi](https://github.com/open-mpi/ompi) (Paralleles Rechnen)
- **BeeGFS/Lustre:** [https://github.com/beegfs/beegfs](https://github.com/beegfs/beegfs) (Cluster-Dateisystem, schnelles Storage-Sharing)
- **NVIDIA vGPU:** [https://www.nvidia.com/en-us/data-center/virtual-solutions/](https://www.nvidia.com/en-us/data-center/virtual-solutions/) (Enterprise)
- **VirtualGL/TurboVNC:** [https://virtualgl.org/](https://virtualgl.org/) (Remote 3D/GL-Rendering)
- **OpenNebula/Harvester:** Verwaltung von VMs, Storage und GPU in Clustern

## 4. Was geht gut, was weniger?

- **Sehr gut:**  
  - Batch-Jobs, Rendering, KI-Training, Simulationen → Cluster verteilt Aufgaben optimal.
  - Remote-Desktop auf leistungsfähigen Cluster-Node → "schwacher" PC fühlt sich wie High-End an.
- **Begrenzt:**  
  - RAM oder GPU direkt als "Erweiterung" für einen einzelnen Prozess auf dem Desktop ist technisch schwierig (Latenz, Netzwerk).
  - Windows-Spiele/Anwendungen lokal mit Cluster-Power laufen lassen ist sehr aufwendig (Stichwort: Cloud-Gaming/Streaming).

## 5. Fazit

- Ein Cluster kann die Power deines Arbeitsplatzes massiv erweitern, aber meist nicht 1:1 einfach "mehr RAM/GPU" für lokale Anwendungen bringen.
- Typisch ist: Du nutzt den Cluster für große Aufgaben (Rendering, KI, Datenanalyse) oder arbeitest remote auf einem starken Cluster-Node.
- Für "virtuelles RAM/GPU" wie bei Composable Infrastructure sind Enterprise-Lösungen/Cloud nötig (z. B. HPE Synergy, NVIDIA AI Enterprise, OpenNebula, Kubernetes mit GPU-Plugins).

---

**Tipp:**  
Für den Heimgebrauch:  
- Nutze Remote-Desktop auf einen starken Cluster-Node, um die Power zu erleben.
- Für Entwickler/Power-User: Starte Container/VMs auf dem Cluster und greife mit VS Code Remote, Jupyter oder SSH darauf zu.

---

**Linksammlung:**
- [Awesome HPC](https://github.com/awesome-hpc/awesome-hpc)
- [Awesome Selfhosted](https://github.com/awesome-selfhosted/awesome-selfhosted)
- [NVIDIA vGPU](https://www.nvidia.com/en-us/data-center/virtual-solutions/)