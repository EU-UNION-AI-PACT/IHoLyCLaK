# Noch mehr Awesome-Listen (Ergänzung zu Server, DevOps, Selfhosting & IT)

Hier findest du weitere spezialisierte und hilfreiche "Awesome Lists" auf GitHub. Sie decken zahlreiche IT- und Open-Source-Bereiche ab: Cloud, Sicherheit, Netzwerk, Datenbanken, Automatisierung, Web, Programmierung, KI und mehr.

---

## ☁️ Cloud, SaaS, Serverless
- [Awesome DigitalOcean](https://github.com/jonleibowitz/awesome-digitalocean)
- [Awesome Linode](https://github.com/linode/awesome-linode)
- [Awesome Heroku](https://github.com/ianstormtaylor/awesome-heroku)
- [Awesome SaaS Boilerplates](https://github.com/apptension/awesome-saas-boilerplates)
- [Awesome Serverless](https://github.com/anaibol/awesome-serverless)
- [Awesome Cloud Security](https://github.com/Funkmyster/awesome-cloud-security)

## 🌐 Netzwerk, Proxies, DNS, VPN
- [Awesome Networking](https://github.com/briatte/awesome-network-analysis)
- [Awesome Proxy](https://github.com/rateb/awesome-proxy)
- [Awesome VPN](https://github.com/hackjutsu/awesome-vpn)
- [Awesome DNS](https://github.com/jhades/awesome-dns)
- [Awesome WireGuard](https://github.com/vi/webdev/blob/master/awesome-wireguard.md)

## 🔒 Security, Pentesting, Forensics
- [Awesome Blue Team](https://github.com/meitar/awesome-blue-team)
- [Awesome Incident Response](https://github.com/meirwah/awesome-incident-response)
- [Awesome SOC](https://github.com/Security-Community/awesome-soc)
- [Awesome Digital Forensics](https://github.com/Cugu/awesome-forensics)
- [Awesome CTF](https://github.com/apsdehal/awesome-ctf)
- [Awesome Malware Analysis](https://github.com/rshipp/awesome-malware-analysis)
- [Awesome AppSec](https://github.com/paragonie/awesome-appsec)

## 📚 Doku, Tools & Wissen für Admins
- [Awesome Cheat Sheets](https://github.com/LeCoupa/awesome-cheatsheets)
- [Awesome SysAdmin](https://github.com/awesome-foss/awesome-sysadmin)
- [Awesome Remote Job](https://github.com/lukasz-madon/awesome-remote-job)
- [Awesome DevSecOps](https://github.com/TaptuIT/awesome-devsecops)
- [Awesome Incident Management](https://github.com/blameless/awesome-incident-management)
- [Awesome Open Source Documentation](https://github.com/PharkMillups/beautiful-docs)

## 🗄️ Datenbanken & Storage
- [Awesome NoSQL](https://github.com/erictleung/awesome-nosql)
- [Awesome Time Series Database](https://github.com/ty4z2008/Qix/blob/master/awesome-database.md#time-series)
- [Awesome Big Data](https://github.com/onurakpolat/awesome-bigdata)
- [Awesome Object Storage](https://github.com/iqbal-lab-org/awesome-object-storage)

## ⚡ Automation, IaC, Observability
- [Awesome Infrastructure Automation](https://github.com/DavidLambauer/awesome-infrastructure-automation)
- [Awesome Infrastructure as Code](https://github.com/iann0036/awesome-terraform)
- [Awesome GitOps](https://github.com/weaveworks/awesome-gitops)
- [Awesome Observability](https://github.com/adriannadiaz/awesome-observability)
- [Awesome Monitoring](https://github.com/crazy-canux/awesome-monitoring)

## 🤖 KI, ML & Data Science
- [Awesome Machine Learning](https://github.com/josephmisiti/awesome-machine-learning)
- [Awesome Deep Learning](https://github.com/ChristosChristofidis/awesome-deep-learning)
- [Awesome NLP](https://github.com/keon/awesome-nlp)
- [Awesome Computer Vision](https://github.com/jbhuang0604/awesome-computer-vision)
- [Awesome AI in Production](https://github.com/InsightDataScience/awesome-ai-in-production)
- [Awesome Data Science](https://github.com/academic/awesome-datascience)
- [Awesome Open Data](https://github.com/okfn/awesome-opendata)

## 💻 Programmierung & Tools
- [Awesome Python](https://github.com/vinta/awesome-python)
- [Awesome Go](https://github.com/avelino/awesome-go)
- [Awesome Rust](https://github.com/rust-unofficial/awesome-rust)
- [Awesome Java](https://github.com/akullpp/awesome-java)
- [Awesome C/C++](https://github.com/fffaraz/awesome-cpp)
- [Awesome Bash](https://github.com/awesome-lists/awesome-bash)
- [Awesome Shell](https://github.com/alebcay/awesome-shell)
- [Awesome CLI Apps](https://github.com/agarrharr/awesome-cli-apps)
- [Awesome Dotfiles](https://github.com/webpro/awesome-dotfiles)

## 🔗 Meta & weitere Übersichten
- [Awesome Lists (Meta)](https://github.com/sindresorhus/awesome)
- [Awesome Lists by Topic](https://github.com/topics/awesome-list)
- [Awesome Open Source](https://github.com/open-source-ideas/awesome-open-source-ideas)

---

**Noch mehr?**  
Schau einfach auf [github.com/sindresorhus/awesome](https://github.com/sindresorhus/awesome) oder suche auf GitHub nach `awesome <Thema>`!
