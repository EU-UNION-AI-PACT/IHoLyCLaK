# MCP & One-Click-Deployment: Repos & Tools für moderne Orchestrierung

## ⚙️ Management Control Plane (MCP) & Resource Orchestrierung

- **Rancher**
  - [https://github.com/rancher/rancher](https://github.com/rancher/rancher)
  - Multi-Cluster, Multi-Cloud K8s-Management, UI, RBAC, App-Store

- **OpenNebula**
  - [https://github.com/OpenNebula/one](https://github.com/OpenNebula/one)
  - Open-Source Cloud & Edge MCP: VM, Container, Storage, Network-Orchestrierung

- **Harvester**
  - [https://github.com/harvester/harvester](https://github.com/harvester/harvester)
  - HCI (Hyperconverged Infrastructure), VM+Container Management, Rancher-Integration

- **KubeVirt**
  - [https://github.com/kubevirt/kubevirt](https://github.com/kubevirt/kubevirt)
  - K8s-native VMs & Container-Orchestrierung

- **Kubermatic**
  - [https://github.com/kubermatic/kubermatic](https://github.com/kubermatic/kubermatic)
  - Multi-Cluster, Multi-Cloud, API-first Kubernetes Control Plane

- **OpenShift (OKD)**
  - [https://github.com/openshift/okd](https://github.com/openshift/okd)
  - RedHat’s Enterprise Kubernetes, Operator Hub, GitOps CI/CD

- **Morpheus Data (Open-Core)**
  - [https://github.com/gomorpheus/morpheus-plugin-sdk](https://github.com/gomorpheus/morpheus-plugin-sdk)
  - Multi-Cloud, Baremetal, K8s, VMware, OpenStack, uvm.

---

## 🚀 One-Click Deployment & Stack Templates

- **Portainer**
  - [https://github.com/portainer/portainer](https://github.com/portainer/portainer)
  - Docker/K8s-UI, Stacks, eigene JSON/YAML-Templates, One-Click Deployment
  - Beispiel-Templates:  
    - [https://github.com/technorabilia/portainer-templates](https://github.com/technorabilia/portainer-templates)
    - [https://github.com/portainer/templates](https://github.com/portainer/templates)

- **Awesome Compose**
  - [https://github.com/docker/awesome-compose](https://github.com/docker/awesome-compose)
  - Über 100+ Docker Compose Stacks (AI, ML, DevOps, Media, Analytics, uvm.)

- **Awesome Selfhosted**
  - [https://github.com/awesome-selfhosted/awesome-selfhosted](https://github.com/awesome-selfhosted/awesome-selfhosted)
  - Tausende Apps, oft mit Docker/Compose/Helm Templates

- **Kubeapps**
  - [https://github.com/vmware-tanzu/kubeapps](https://github.com/vmware-tanzu/kubeapps)
  - Helm-Chart UI, One-Click Install für K8s Apps

- **Helm Hub**
  - [https://artifacthub.io/](https://artifacthub.io/)
  - Zentrale Chart-Suche (AI, DevOps, Monitoring, DBs, etc.)

- **Unraid Community Apps**
  - [https://github.com/selfhosters/unRAID-CA-templates](https://github.com/selfhosters/unRAID-CA-templates)
  - Templates für Container, VMs, Stacks – auch AI/HPC/DevOps

- **Yacht**
  - [https://github.com/SelfhostedPro/Yacht](https://github.com/SelfhostedPro/Yacht)
  - Portainer-Alternative: UI für One-Click Docker-Deployments

---

## 🧠 High-Performance, AI & DevOps Stacks

- **LSIO Compose Templates**
  - [https://github.com/linuxserver/docker-compose-templates](https://github.com/linuxserver/docker-compose-templates)
  - Viele DevOps, Media, Database, AI Stacks

- **K8s-at-home**
  - [https://github.com/k8s-at-home/charts](https://github.com/k8s-at-home/charts)
  - Kubernetes-Helmcharts für Selfhosting, AI, Media, DevOps

- **OneDr0p Home-Cluster**
  - [https://github.com/onedr0p/home-cluster](https://github.com/onedr0p/home-cluster)
  - Komplettes K8s-Repo: AI, Monitoring, DevOps, Media

- **Awesome HPC**
  - [https://github.com/awesome-hpc/awesome-hpc](https://github.com/awesome-hpc/awesome-hpc)
  - Tools, Scheduler, Cluster-Management für High-Performance Computing

---

**Tipp:**  
Mit diesen Tools kannst du MCP/Control Plane, Virtualisierung, Stacks und One-Click-Deployments für fast jede Anforderung kombinieren – von HomeLab bis Enterprise/AI/HPC.