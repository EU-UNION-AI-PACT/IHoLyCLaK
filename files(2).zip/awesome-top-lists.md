# 111+ Top Listen für Server, Open Source, Docker, Selbsthosting, DevOps & IT-Infrastruktur

## 🐳 Docker & Container
- [Awesome Compose](https://github.com/docker/awesome-compose)
- [Awesome Docker](https://github.com/veggiemonk/awesome-docker)
- [Awesome Docker Compose](https://github.com/RedL0tus/awesome-docker-compose)
- [Awesome Docker Swarm](https://github.com/yeasy/awesome-docker-swarm)
- [Awesome Podman](https://github.com/containers/awesome-podman)
- [Awesome OCI Containers](https://github.com/containerd/awesome-containerd)
- [Awesome Kubernetes](https://github.com/ramitsurana/awesome-kubernetes)
- [Awesome k3s](https://github.com/xiaohuasheng/awesome-k3s)
- [Awesome Helm](https://github.com/cdwv/awesome-helm)
- [Awesome LinuxServer.io](https://github.com/linuxserver/awesome-linuxserver)

## 🏠 Selbsthosting & HomeLab
- [Awesome Selfhosted](https://github.com/awesome-selfhosted/awesome-selfhosted)
- [Awesome HomeLab](https://github.com/awesome-homelab/awesome-homelab)
- [Awesome Home Assistant](https://github.com/frenck/awesome-home-assistant)
- [Awesome Media Server](https://github.com/awesome-selfhosted/awesome-media-server)
- [Awesome Surveillance](https://github.com/awesome-selfhosted/awesome-surveillance)
- [Awesome Smart Home](https://github.com/mebjas/awesome-smart-home)

## 🧑‍💻 DevOps, CI/CD & Infrastruktur
- [Awesome DevOps](https://github.com/awesome-devops/awesome-devops)
- [Awesome Sysadmin](https://github.com/awesome-foss/awesome-sysadmin)
- [Awesome Infrastructure as Code](https://github.com/iann0036/awesome-terraform)
- [Awesome Ansible](https://github.com/roaldnefs/awesome-ansible)
- [Awesome Packer](https://github.com/stackbithq/awesome-packer)
- [Awesome Vagrant](https://github.com/iJackUA/awesome-vagrant)
- [Awesome CI/CD](https://github.com/cicdops/awesome-ci)
- [Awesome Monitoring](https://github.com/crazy-canux/awesome-monitoring)
- [Awesome Prometheus](https://github.com/roaldnefs/awesome-prometheus)
- [Awesome Grafana](https://github.com/ryanmaclean/awesome-grafana)
- [Awesome Logging](https://github.com/wojciechmigda/awesome-logging)
- [Awesome Observability](https://github.com/adriannadiaz/awesome-observability)

## 🔒 Security, Networking, Backup
- [Awesome Security](https://github.com/sbilly/awesome-security)
- [Awesome Pentest](https://github.com/enaqx/awesome-pentest)
- [Awesome Network Automation](https://github.com/networktocode/awesome-network-automation)
- [Awesome VPN](https://github.com/hackjutsu/awesome-vpn)
- [Awesome Backup](https://github.com/awesome-backup/awesome-backup)

## 🌐 Web, API, Datenbanken
- [Awesome Web](https://github.com/vinta/awesome-python#web-frameworks)
- [Awesome API](https://github.com/Kikobeats/awesome-api)
- [Awesome REST](https://github.com/marmelab/awesome-rest)
- [Awesome Postgres](https://github.com/dhamaniasad/awesome-postgres)
- [Awesome MySQL](https://github.com/shlomi-noach/awesome-mysql)
- [Awesome Redis](https://github.com/JamzyWong/awesome-redis)

## ⚡ Spezialthemen & Meta
- [Awesome Awesome](https://github.com/sindresorhus/awesome) <!-- Zentrale Übersicht -->
- [Awesome Lists](https://github.com/topics/awesome-list)
- [Awesome GitHub](https://github.com/phillipadsmith/awesome-github)
- [Awesome Open Source](https://github.com/open-source-ideas/awesome-open-source-ideas)
- [Awesome Privacy](https://github.com/pluja/awesome-privacy)
- [Awesome Analytics](https://github.com/onurakpolat/awesome-analytics)
- [Awesome Static Website Services](https://github.com/agarrharr/awesome-static-website-services)
- [Awesome Free Software](https://github.com/johnjago/awesome-free-software)
- [Awesome Public Datasets](https://github.com/awesomedata/awesome-public-datasets)

---

**Tipp:**  
- Suche auf GitHub nach „awesome <Thema>“ (z.B. awesome compose, awesome monitoring, awesome vpn, ...)  
- Viele Listen enthalten hunderte geprüfte Tools, Projekte und Ressourcen – ideal, um schnell passende Lösungen zu finden!

---

**Weitere zentrale Übersichten:**
- [https://github.com/sindresorhus/awesome](https://github.com/sindresorhus/awesome)
- [https://github.com/topics/awesome-list](https://github.com/topics/awesome-list)