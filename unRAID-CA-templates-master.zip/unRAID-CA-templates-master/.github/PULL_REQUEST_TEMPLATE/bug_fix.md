---
name: CA Template Fix
about: For issuing a fix for a template
title: Template Fix Request - <application name>
labels: Broken Template
assignees: ''

---

### Before submitting a *pull request* make sure you have

- [ ] Checked that there is no [open issue](https://github.com/selfhosters/unRAID-CA-templates/issues?q=is%3Aissue+is%3Aopen).
- [ ] A member from [Templaters team](https://github.com/orgs/selfhosters/teams/templaters/members) has not acknowledged this issue elsewhere.

---

### Description of your *pull request* and other information

Help us investigate this bug, link the discovery for the issue (like a forum post).

If there is currently an open issue regarding this issue, please link this here.
