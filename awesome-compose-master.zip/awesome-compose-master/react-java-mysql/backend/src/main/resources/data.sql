INSERT INTO example.greetings(name) values ('Docker');
