ln -s ../docker-env.cfg ./.env
. ./.env
mkdir -p ${BASEDIR:-/srv/lsio}/mylar3/config
mkdir -p ${BASEDIR:-/srv/lsio}/mylar3/comics
mkdir -p ${BASEDIR:-/srv/lsio}/mylar3/downloads
