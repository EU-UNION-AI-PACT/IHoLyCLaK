# [Dokuwiki](https://www.dokuwiki.org/dokuwiki/) is a simple to use and highly
# versatile Open Source wiki software that doesn't require a database. It is
# loved by users for its clean and readable syntax. The ease of maintenance,
# backup and integration makes it an administrator's favorite. Built in access
# controls and authentication connectors make DokuWiki especially useful in the
# enterprise context and the large number of plugins contributed by its vibrant
# community allow for a broad range of use cases beyond a traditional wiki.

. ./.env
docker run -d \
  --name=dokuwiki \
  -e PUID=${PUID:-1000} `# Run 'id [USER]' for the owner of the host volume directories to get the UID to use here.` \
  -e PGID=${PGID:-1000} `# Run 'id [USER]' for the owner of the host volume directories to get the GID to use here.` \
  -e TZ=${TZ:-Etc/UTC} `# specify a timezone to use, see this [list](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones#List).` \
  -p 80:80 `# Application HTTP Port` \
  -p 443:443 `# #optional Application HTTPS Port [OPTIONAL]` \
  -v ${BASEDIR:-/srv/lsio}/dokuwiki/config:/config `# Persistent config files` \
  --restart unless-stopped \
  lscr.io/linuxserver/dokuwiki:latest
